const profileModel = require('./profileModel');
module.exports.getUserByUserName = profileModel.getUserByUserName;
module.exports.insertUser = profileModel.insertUser;
module.exports.fetchuser = profileModel.fetchuser;
